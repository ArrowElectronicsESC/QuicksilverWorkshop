--------------------------------------------
QuicksilverEval - README
--------------------------------------------

Provider    : Arrow
Website     : ?????
Description : Arrow QuicksilverEval

Module
  Mfr       : Arrow
  P/N       : QuicksilverEval
  MCU       : CYW943907 Cortex-R4 320MHz  (Apps Core)
  WLAN      : CYW943907 Cortex-R4 (WLAN Core)
  WLAN Antennas : Diversity with two printed antennae

--------------------------------------------
Board Revisions
--------------------------------------------

P200        ChipRevision : B1