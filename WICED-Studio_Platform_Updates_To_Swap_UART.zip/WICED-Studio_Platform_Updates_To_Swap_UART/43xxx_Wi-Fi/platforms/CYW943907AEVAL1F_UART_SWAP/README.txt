--------------------------------------------
CYW943907AEVAL1F - README
--------------------------------------------

Provider    : Cypress
Description : Cypress CYW943907AEVAL1F

Module
  Mfr       : Cypress
  P/N       : CYW943907AEVAL1F
  MCU       : CYW943907 Cortex-R4 320MHz  (Apps Core)
  WLAN      : CYW943907 Cortex-R4 (WLAN Core)
  WLAN Antennas : Diversity with two printed antennae (and in-line switched Murata MM8130 connectors)

--------------------------------------------
Board Revisions
--------------------------------------------

P103        ChipRevision : B1