--------------------------------------------
README
--------------------------------------------
This folder contains the below power database files used by the WICED POWER LOGGER tool.

CYW943907AEVAL1F.xml --> Platform power data
CYW943907AEVAL1F_tx_WiFi.xml --> Wi-Fi Power data for tx 
CYW943907AEVAL1F_rx_WiFi.xml --> Wi-Fi Power data for rx